package com.acarainservices.acarainservices.transaction;

import org.springframework.data.repository.CrudRepository;

public interface TransactionRepo extends CrudRepository<Transaction, Integer> {

}
