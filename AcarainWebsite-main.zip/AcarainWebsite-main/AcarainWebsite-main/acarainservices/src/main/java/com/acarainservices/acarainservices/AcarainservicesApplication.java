package com.acarainservices.acarainservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcarainservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcarainservicesApplication.class, args);
	}

}
